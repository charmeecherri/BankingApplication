﻿using System;
using System.Collections.Generic;

namespace BankingApp
{
    class Program
    {
        static void Main(string[] args)
        {
            BankingSystem bankingSystem = new BankingSystem();
            bankingSystem.Run();
        }
    }
}

